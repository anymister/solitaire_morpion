from keras.optimizers import Adam
from keras.models import Sequential
from keras.layers.core import Dense, Dropout
import random
import numpy as np
import pandas as pd
from operator import add

class DQNAgent(object):

    def __init__(self):
        self.reward = 0
        self.gamma = 0.9
        self.dataframe = pd.DataFrame()
        self.short_memory = np.array([])
        self.agent_target = 1
        self.agent_predict = 0
        self.learning_rate = 0.0005
        self.model = self.network()
        #self.model = self.network("weights.hdf5")
        self.epsilon = 0
        self.actual = []
        self.memory = []


    def get_state(self,game):
        state=[]
        direction1,direction2,direction3=False,False,False
        for i in range(len(game.rep_playable_lines)):
            for j in range(game.liberte):
                if (game.rep_playable_lines[i][0][0].x==game.x_player-j and game.rep_playable_lines[i][0][0].y==game.y_player-j):
                    direction1=True
                if (game.rep_playable_lines[i][0][0].x==game.x_player-j and game.rep_playable_lines[i][0][0].y==game.y_player+j):
                    direction2=True
                if (game.rep_playable_lines[i][0][0].x==game.x_player+j and game.rep_playable_lines[i][0][0].y==game.y_player):
                    direction3=True
        for i in range(71):
            state.append(False)
        state[game.x_player]=True
        state[game.y_player]=True
        state[60]=game.choosed_line[0][0].x<game.x_player 
        state[61]=       game.choosed_line[0][0].x>game.x_player 
        state[62]= game.choosed_line[0][0].y<game.y_player 
        state[63]= game.choosed_line[0][0].y>game.y_player
        state[64]=direction1 # s'il y a une cellule jouable autour
        state[65]=direction2
        state[66]=direction3
        state[67]=game.move==[1,0,0]  # dernier deplacement
        state[68]=game.move==[0,1,0] 
        state[69]=game.move==[0,0,1] 
        state[70]=game.cpt_liberte>game.liberte-3 # danger
        for i in range(len(state)):
            if state[i]:
                state[i]=1
            else:
                state[i]=0
        return np.asarray(state)

    def set_reward(self, crash, found):
        self.reward = 0
        if crash==0:
            self.reward = -10
        if found:
            self.reward = 10

        return self.reward
    
    def network(self, weights=None):
        model = Sequential()
        model.add(Dense(output_dim=120, activation='relu', input_dim=71))
        model.add(Dropout(0.15))
        model.add(Dense(output_dim=120, activation='relu'))
        model.add(Dropout(0.15))
        model.add(Dense(output_dim=120, activation='relu'))
        model.add(Dropout(0.15))
        model.add(Dense(output_dim=8, activation='softmax'))
        opt = Adam(self.learning_rate)
        model.compile(loss='mse', optimizer=opt)

        if weights:
            model.load_weights(weights)
        return model

    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def replay_new(self, memory):
        if len(memory) > 1000:
            minibatch = random.sample(memory, 1000)
        else:
            minibatch = memory
        for state, action, reward, next_state, done in minibatch:
            target = reward
            if not done:
                target = reward + self.gamma * np.amax(self.model.predict(np.array([next_state]))[0])
            target_f = self.model.predict(np.array([state]))
            target_f[0][np.argmax(action)] = target
            self.model.fit(np.array([state]), target_f, epochs=1, verbose=0)

    def train_short_memory(self, state, action, reward, next_state, done):
        target = reward
        if not done:
            target = reward + self.gamma * np.amax(self.model.predict(next_state.reshape((1, 71)))[0])
        target_f = self.model.predict(state.reshape((1, 71)))
        target_f[0][np.argmax(action)] = target
        self.model.fit(state.reshape((1, 71)), target_f, epochs=1, verbose=0)
